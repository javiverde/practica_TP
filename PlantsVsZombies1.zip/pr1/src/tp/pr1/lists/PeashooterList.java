package tp.pr1.lists;
import tp.pr1.elements.*;

public class PeashooterList {


	private int size = 0;
	private Peashooter[] peashooters;

	public PeashooterList()
	{
		this.peashooters =  new Peashooter[10];
	}

	public Peashooter[] getPeashooters() {
		return peashooters;
	}

	public void addPeashooter(Peashooter peashooter)
	{
		if(size < peashooters.length)
		{
			peashooters[size] = peashooter;
			size++;
		}
	}

	public int getSize() {
		return size;
	}

	public void setSize(int size) {
		this.size = size;
	}

	public void eraserPeashooter()
	{
		int count = 0;

		for(int i=0; i < size; i++)
		{
			if(peashooters[i].getHealthPoints() == 0)
			{
				count = i;

				for(int j= count; j < size; j++)
				{
					peashooters[j] = peashooters[j+1];
				}

				size--;
			}
		}
	}


	public boolean PeashooterEmpty(int x, int y)
	{
		boolean empty = true;

		for(int i=0; i < size; i++)
		{
			if(peashooters[i].getPos_x() == x && peashooters[i].getPos_y() == y)
			{
				empty = false;
			}
		}

		return empty;
	}


	public void update()
	{
		for(int i=0; i < size; i++)
		{
			peashooters[i].update();
		}
	}




	public int position(int x, int y)
	{
		int position = 0;

		for(int i = 0; i < size; i++)
		{
			if(peashooters[i].getPos_x() == x && peashooters[i].getPos_y() == y)
			{
				position = i;
			}			
		}
		return position;
	}

	public String peashooterString(int i)
	{
		return peashooters[i].toString();
	}

	public void peashooterDamaged(int x, int y)
	{
		for(int i= 0; i < size; i++)
		{
			if(peashooters[i].getPos_x() == x && peashooters[i].getPos_y() == y)
			{
				peashooters[i].Damage();
			}
		}
	}






}
