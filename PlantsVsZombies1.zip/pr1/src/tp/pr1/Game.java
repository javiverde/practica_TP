package tp.pr1;
import tp.pr1.elements.*;
import tp.pr1.lists.*;

import java.util.Random;

public class Game {

	private Level level;

	private SunflowerList sunflowerlist = new SunflowerList();
	private ZombieList zombielist = new ZombieList();
	private PeashooterList peashooterlist = new PeashooterList();
	private SuncoinManager suncoinmanager;
	private ZombieManager zombiemanager;
	private GamePrinter gameprinter;
	private int numCycles;
	private Random rand;

	public Game(Level level, Random rand)
	{
		this.numCycles = 0;
		this.level = level;
		this.rand = rand;
		this.suncoinmanager = new SuncoinManager();
		this.gameprinter = new GamePrinter(this, 4, 8);
		this.zombiemanager = new ZombieManager();
	}



	public GamePrinter getGameprinter() {
		return gameprinter;
	}



	public Level getLevel() {
		return level;
	}


	public Random getRand() {
		return rand;
	}


	public int getNumCycles() {
		return numCycles;
	}



	public void update()
	{

		zombielist.update();
		peashooterlist.update();
		sunflowerlist.update();
		zombielist.eraserZombie();
		peashooterlist.eraserPeashooter();
		sunflowerlist.eraserSunflower();
		gameprinter = new GamePrinter(this, 4, 8);
		
	}	



	public String toString()
	{
		String info = "Number of cycles: " + numCycles + "\n" +"Sun coins: " + suncoinmanager.getSuncoins() + "\n" + "Remaining zombies: " + zombiemanager.getZombiesLeftToAppear() + "\n" + gameprinter.toString();

		return info;

	}

	public SunflowerList getSunflowerlist() {
		return sunflowerlist;
	}

	public ZombieList getZombielist() {
		return zombielist;
	}

	public PeashooterList getPeashooterlist() {
		return peashooterlist;
	}


	public ZombieManager getZombiemanager() {
		return zombiemanager;
	}

	public SuncoinManager getSuncoinmanager() {
		return suncoinmanager;
	}

	public void setNumCycles(int numCycles) {
		this.numCycles = numCycles;
	}

	
	public void addSunflower(Sunflower sunflower)
	{
		sunflowerlist.addSunflower(sunflower);
	}
	

	public void addZombie(Zombie zombie)
	{
		zombielist.addZombie(zombie);
	}
	

	public void addPeashooter(Peashooter peashooter)
	{
		peashooterlist.addPeashooter(peashooter);
	}
	

	public boolean getSfInPosition(int x, int y)
	{
		boolean isSunflower = false;


		if(!sunflowerlist.SunflowerEmpty(x, y))
		{
			isSunflower = true;
		}

		return isSunflower;
	}


	public boolean getPsInPosition(int x, int y)
	{
		boolean isPeashooter = false;

		if(!peashooterlist.PeashooterEmpty(x, y))
		{
			isPeashooter = true;
		}

		return isPeashooter;
	}


	public boolean getZInPosition(int x, int y)
	{
		boolean isZombie = false;


		if(!zombielist.ZombieEmpty(x, y))
		{
			isZombie = true;
		}

		return isZombie;

	}


	public String findCharacter(int x, int y)
	{
		String character;

		if(!zombielist.ZombieEmpty(x, y))
		{
			character = zombielist.zombieString(zombielist.position(x, y));
		}
		else if(!peashooterlist.PeashooterEmpty(x, y))
		{
			character = peashooterlist.peashooterString(peashooterlist.position(x, y));
		}
		else if(!sunflowerlist.SunflowerEmpty(x, y))
		{
			character = sunflowerlist.sunflowerString(sunflowerlist.position(x, y));
		}
		else
		{
			character = " ";
		}


		return character;
	}

	public boolean isEmpty(int x, int y)
	{
		boolean empty = false;

		if(zombielist.ZombieEmpty(x, y) && sunflowerlist.SunflowerEmpty(x, y) && peashooterlist.PeashooterEmpty(x, y))
		{
			empty = true;
		}

		return empty;
	}
	
	public void peashooterDamaged(int x, int y)
	{
		peashooterlist.peashooterDamaged(x, y);
	}
	
	public void sunflowerDamaged(int x, int y)
	{
		sunflowerlist.sunflowerDamaged(x,y);
	}
	
	public void zombieDamaged(int x, int y)
	{
		zombielist.Damage(x, y);
	}
	
	public boolean endGame()
	{
		boolean end = false;
		
		for(int i = 0; i < gameprinter.dimX ; i++)
		{
			
			if(!zombielist.ZombieEmpty(i, 0))
			{
				end = true;
				System.out.println("Zombies win");
				System.exit(0);
			}
		}
		
		if(zombiemanager.getZombiesLeftToAppear() == 0 && zombielist.getSize() == 0)
		{
			end = true;
			System.out.println("Player wins");
			System.exit(0);
		}
		
		return end;

	}
	
	



}
