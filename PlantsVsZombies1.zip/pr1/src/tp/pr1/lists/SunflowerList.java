package tp.pr1.lists;
import tp.pr1.elements.*;

public class SunflowerList {

	private int size = 0;
	private Sunflower[] sunflowers;

	public SunflowerList()
	{
		this.sunflowers =  new Sunflower[10];
	}

	public Sunflower[] getSunflowers() {
		return sunflowers;
	}

	public void addSunflower(Sunflower sunflower)
	{
		if(size < sunflowers.length)
		{
			sunflowers[size] = sunflower;
			size++;
		}
	}

	public int getSize() {
		return size;
	}

	public void setSize(int size) {
		this.size = size;
	}

	public void eraserSunflower()
	{
		int count = 0;

		for(int i=0; i < size; i++)
		{
			if(sunflowers[i].getHealthPoints() == 0)
			{
				count = i;

				for(int j= count; j < size; j++)
				{
					sunflowers[j] = sunflowers[j+1];
				}

				size--;
			}
		}
	}

	public boolean SunflowerEmpty(int x, int y)
	{
		boolean empty = true;

		for(int i=0; i < size; i++)
		{
			if(sunflowers[i].getPos_x() == x && sunflowers[i].getPos_y() == y)
			{
				empty = false;
			}
		}

		return empty;
	}

	public void sunflowerDamaged(int x, int y)
	{
		for(int i= 0; i < size; i++)
		{
			if(sunflowers[i].getPos_x() == x && sunflowers[i].getPos_y() == y)
			{
				sunflowers[i].Damage();
			}
		}
	}

	public int position(int x, int y)
	{
		int position = 0;

		for(int i = 0; i < size; i++)
		{
			if(sunflowers[i].getPos_x() == x && sunflowers[i].getPos_y() == y)
			{
				position = i;
			}			
		}
		return position;
	}


	public String sunflowerString(int i)
	{
		return sunflowers[i].toString();
	}

	public void update()
	{
		for(int i = 0; i < size; i++)
		{
			sunflowers[i].update();
		}
	}


}
