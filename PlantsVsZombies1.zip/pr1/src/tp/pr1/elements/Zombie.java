package tp.pr1.elements;
import tp.pr1.*;

public class Zombie {

	private int pos_x;
	private int pos_y;
	private int healthPoints = 5;
	private static int SPEED = 1;
	private static int DAMAGE = 1;
	private Game game;
	private int inputCycle;


	public Zombie(int x, int y, Game game, int inputCycles) {

		this.pos_x = x;
		this.pos_y = y;
		this.game = game;
		this.inputCycle = inputCycles;
	}

	public int getPos_x() {
		return pos_x;
	}

	public void setPos_x(int pos_x) {
		this.pos_x = pos_x;
	}

	public int getPos_y() {
		return pos_y;
	}

	public void setPos_y(int pos_y) {
		this.pos_y = pos_y;
	}

	public int getHealthPoints() {
		return healthPoints;
	}

	public void setHealthPoints(int healthPoints) {
		this.healthPoints = healthPoints;
	}

	public static int getSPEED() {
		return SPEED;
	}

	public static int getDAMAGE() {
		return DAMAGE;
	}

	public Game getGame() {
		return game;
	}


	public void Damage()
	{
		if(healthPoints > 0)
		{
			setHealthPoints(healthPoints - Peashooter.getDAMAGE());
		}
	}


	public void update()
	{
		if(game.getNumCycles()%2 == 0 && inputCycle%2 == 0 || game.getNumCycles()%2 != 0 && inputCycle%2 != 0)
		{
			if(game.isEmpty(pos_x, pos_y-1))
			{

				setPos_y(pos_y-1);
			}	
		}
		
		attack();


	}
	
	public void attack()
	{
		if(game.getPsInPosition(pos_x, pos_y-1))
		{
			game.peashooterDamaged(pos_x, pos_y-1);
		}
		else if(game.getSfInPosition(pos_x, pos_y-1))
		{
			game.sunflowerDamaged(pos_x, pos_y-1);
		}
	}
	

	public String toString() {
		return "Z["+ healthPoints + "]";
	}

}


