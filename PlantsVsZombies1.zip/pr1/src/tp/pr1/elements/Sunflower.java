package tp.pr1.elements;
import tp.pr1.*;

public class Sunflower {

	private int pos_x;
	private int pos_y;
	private int healthPoints = 1;
	private static int COST = 20;
	private static int FREQUENCY = 10;
	private static int DAMAGE = 0;
	private Game game;
	private int inputCycle;




	public Sunflower(int x, int y, Game game, int inputCycle) {

		this.pos_x = x;
		this.pos_y = y;
		this.game = game;
		this.inputCycle = inputCycle;
	}

	public int getPos_x() {
		return pos_x;
	}

	public void setPos_x(int pos_x) {
		this.pos_x = pos_x;
	}

	public int getPos_y() {
		return pos_y;
	}

	public void setPos_y(int pos_y) {
		this.pos_y = pos_y;
	}

	public int getHealthPoints() {
		return healthPoints;
	}

	public void setHealthPoints(int healthPoints) {
		this.healthPoints = healthPoints;
	}

	public static int getCOST() {
		return COST;
	}

	public static int getFREQUENCY() {
		return FREQUENCY;
	}

	public Game getGame() {
		return game;
	}

	public static int getDAMAGE() {
		return DAMAGE;
	}

	public String toString() {
		return "S[" + healthPoints + "]";
	}

	public void Damage()
	{

		if(healthPoints > 0)
		{
			setHealthPoints(healthPoints - Zombie.getDAMAGE());
		}
	}


	public void update()
	{

		if(game.getNumCycles()%2 == 0 && inputCycle%2 == 0 || game.getNumCycles()%2 != 0 && inputCycle%2 != 0)
		{
			game.getSuncoinmanager().updateSuncoins();
		}
	}



}
