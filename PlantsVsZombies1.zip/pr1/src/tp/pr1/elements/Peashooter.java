package tp.pr1.elements;
import tp.pr1.*;

public class Peashooter {

	private int pos_x;
	private int pos_y;
	private int healthPoints = 3;
	private static int COST = 50;
	private static int FREQUENCY = 1;
	private static int DAMAGE = 1;
	private Game game;

	public Peashooter(int x, int y, Game game)
	{
		this.pos_x = x;
		this.pos_y = y;
		this.game = game;	
	}

	public int getPos_x() {
		return pos_x;
	}

	public void setPos_x(int pos_x) {
		this.pos_x = pos_x;
	}

	public int getPos_y() {
		return pos_y;
	}

	public void setPos_y(int pos_y) {
		this.pos_y = pos_y;
	}

	public int getHealthPoints() {
		return healthPoints;
	}

	public void setHealthPoints(int healthPoints) {
		this.healthPoints = healthPoints;
	}

	public static int getCOST() {
		return COST;
	}

	public static int getFREQUENCY() {
		return FREQUENCY;
	}

	public static int getDAMAGE() {
		return DAMAGE;
	}

	public Game getGame() {
		return game;

	}

	public void update()
	{
		for(int j = 0; j < 8; j++)
		{
			if(game.getZInPosition(pos_x, j))
			{
				game.zombieDamaged(pos_x, j);
			}
		}
	}


	public void Damage()
	{
		if(healthPoints > 0)
		{
			setHealthPoints(healthPoints - Zombie.getDAMAGE());
		}

	}

	public String toString() {
		return "P["+ healthPoints + "]";
	}



}
