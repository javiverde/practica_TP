package tp.pr1;

public enum Level
{
	EASY, HARD, INSANE;
	

	
		
	public int getNumzombies(Level option)
	{
		int n;
		
		if( option == Level.EASY)
		{
			n = 3;
		}
		else if(option == Level.HARD)
		{
			n = 5;
		}
		else
		{
			n = 10;
		}
		
		return n;
	}

	public double getFrequency(Level option)
	{
		double frequency;
		
		if( option == Level.EASY)
		{
			frequency = 0.1;
		}
		else if(option == Level.HARD)
		{
			frequency = 0.2;
		}
		else
		{
			frequency = 0.3;
		}
		
		return frequency;
	}
	
}
