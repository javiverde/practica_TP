//Javier Verde Marin
package tp.pr1;
import java.util.Random;
import java.util.Scanner;

public class PlantsVsZombies {

	public static void main(String[] args) {

		int seed = 0;
		Level level = Level.EASY;
		Scanner scanner = new Scanner(System.in);


		if(args.length == 0)
		{
			System.out.println("ERROR");
			System.exit(0);
		}


		if(args[0].equals("EASY")){
			level =  Level.EASY;
		}
		else if(args[0].equals("HARD"))
		{
			level = Level.HARD;

		}
		else
		{
			level = Level.INSANE;
		}

		if(args.length == 1 )
		{
			Random rand = new Random();
			seed= rand.nextInt(15);
		}
		else if(args.length == 2)
		{
			seed = Integer.parseInt(args[1]);
		}
		else
		{
			System.out.println("ERROR");
		}

		Game game = new Game(level, new Random(seed));
		System.out.println("Random seed used: " + seed);
		Controller control = new Controller(game,scanner);
		control.run();



	}
}

