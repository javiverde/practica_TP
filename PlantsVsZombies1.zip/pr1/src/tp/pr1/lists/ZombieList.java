package tp.pr1.lists;
import tp.pr1.elements.*;

public class ZombieList {

	private int size = 0;
	private Zombie[] zombies;

	public ZombieList()
	{
		this.zombies =  new Zombie[10];
	}

	public Zombie[] getZombies() {
		return zombies;
	}

	public void addZombie(Zombie zombie)
	{
		if(size < zombies.length)
		{
			zombies[size] = zombie;
			size++;
		}
	}

	public int getSize() {
		return size;
	}

	public void setSize(int size) {
		this.size = size;
	}

	public void eraserZombie()
	{
		int count = 0;

		for(int i=0; i < size; i++)
		{
			if(zombies[i].getHealthPoints() == 0)
			{
				count = i;

				for(int j= count; j < size; j++)
				{
					zombies[j] = zombies[j+1];
				}

				size--;

			}
		}
	}


	public boolean ZombieEmpty(int x, int y)
	{
		boolean empty = true;

		for(int i=0; i < size; i++)
		{
			if(zombies[i].getPos_x() == x && zombies[i].getPos_y() == y)
			{
				empty = false;
			}
		}

		return empty;
	}

	public int position(int x, int y)
	{
		int position = 0;

		for(int i = 0; i < size; i++)
		{
			if(zombies[i].getPos_x() == x && zombies[i].getPos_y() == y)
			{
				position = i;
			}			
		}
		return position;
	}

	public void Damage(int x, int y)
	{
		for(int i = 0; i < size; i++)
		{
			if(zombies[i].getPos_x() == x && zombies[i].getPos_y() == y)
			{
				zombies[i].Damage();
			}
		}
	}

	public String zombieString(int i)
	{
		return zombies[i].toString();
	}

	public void update()
	{
		for(int i = 0; i < size; i++)
		{
			zombies[i].update();
		}
	}
	
	



}
