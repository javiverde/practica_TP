package tp.pr1;
import tp.pr1.lists.*;
import tp.pr1.elements.*;
import java.util.Scanner;
import java.util.Random;

public class Controller {

	private Game game;
	private Scanner in;
	String[] string_election = new String[4];


	public Controller(Game game, Scanner in)
	{
		this.game = game;
		this.in = in;
	}




	public void run()
	{
		boolean first_cycle = true;
		boolean reset = false;
		String command;

		game.getZombiemanager().setZombiesLeftToAppear(game.getLevel().getNumzombies(game.getLevel()));

		while(!game.endGame())
		{
			if(!first_cycle && !reset)
			{	
				game.update();
			}
			
			draw(game);


			command = userCommand();
			if(command.equals("reset"))
			{
				reset = true;
			}
			else
			{
				reset = false;
			}

			computerAction();

			first_cycle = false;

			if(!reset)
			{
				game.setNumCycles(game.getNumCycles()+1);
			}
		}

		
		draw(game);
	}
          

	private void computerAction() {
		game.getZombiemanager().isZombieAdded(game);
		
	}




	private void draw(Game game) {

		System.out.println(game);
	}
	

	private String userCommand() {
		System.out.print("Command > ");
		string_election = in.nextLine().split(" ");
		if(string_election.length > 0)
		{
			String command = string_election[0].toLowerCase();
			switch(command)
			{
			case "a":
			case "add":
				addCommand();
				return "add";

			case "list":
			case "l":
				listCommand();
				return "list";

			case "help":
			case "h":
				helpCommand();
				return "help";

			case "exit":
			case "e":
				System.out.println("Game Over");
				System.exit(0); 
				return "exit";

			case "reset":
			case "r":
				resetCommand();
				return "reset";

			case "":

				System.out.println(" ");
				break;

			default:
				System.out.println("Unknown command");
				System.out.println(" ");
				userCommand();
				break;
			}
		}

		return "";

	}




	private void resetCommand() {
		Level level = game.getLevel();
		game.getZombiemanager().setZombiesLeftToAppear(level.getNumzombies(level));
		game.getSuncoinmanager().setSuncoins(50);
		game.setNumCycles(0);
		game.getPeashooterlist().setSize(0);
		game.getZombielist().setSize(0);
		game.getSunflowerlist().setSize(0);
		game.update();
	}




	private void helpCommand() {
		System.out.println("Add <plant> <x> <y>: Adds a plant in position x, y.");
		System.out.println("List: Prints the list of available plants.");
		System.out.println("Reset: Starts a new game.");
		System.out.println("Help: Prints this help message.");
		System.out.println("Exit: Terminates the program.");
		System.out.println("[none]: Skips cycle");
		System.out.println(" ");
		userCommand();
	}




	private void listCommand() {
		System.out.println("[S]unflower: Cost: 20 suncoins Harm: 0");
		System.out.println("[P]eashooter: Cost: 50 suncoins Harm: 1");
		System.out.println(" ");
		userCommand();
	}




	private void addCommand() {
		String plant = string_election[1].toLowerCase();
		int PosX = Integer.parseInt(string_election[2]);
		int PosY =  Integer.parseInt(string_election[3]);

		if(plant.equals("p") || plant.equals("peashooter"))
		{


			if(game.getSuncoinmanager().getSuncoins() >= Peashooter.getCOST())
			{

				if(PosX < game.getGameprinter().dimX && PosY < game.getGameprinter().dimY && PosX >= 0 && PosY >= 0 && game.isEmpty(PosX, PosY))
				{
					Peashooter peashooter = new Peashooter(PosX, PosY, game);
					game.addPeashooter(peashooter);
					game.getSuncoinmanager().buyPlant(Peashooter.getCOST());

				}
				else
				{
					System.out.println("Invalid position");
					System.out.println(" ");
					userCommand();			
				}
			}
			else
			{
				System.out.println("Not enough Sun coins");
				System.out.println(" ");
				userCommand();
			}

		}
		else if(plant.equals("s") || plant.equals("sunflower"))
		{

			if(game.getSuncoinmanager().getSuncoins() >= Sunflower.getCOST())
			{
				if(PosX < game.getGameprinter().dimX && PosY < game.getGameprinter().dimY && PosX >= 0 && PosY >= 0 && game.isEmpty(PosX, PosY))
				{
					Sunflower sunflower = new Sunflower(PosX, PosY, game, game.getNumCycles());
					game.addSunflower(sunflower);
					game.getSuncoinmanager().buyPlant(Sunflower.getCOST());
				}
				else
				{
					System.out.println("Invalid position");
					System.out.println(" ");
					userCommand();			
				}
			}
			else
			{
				System.out.println("Not enough Sun coins");
				System.out.println(" ");
				userCommand();
			}
		}

		else
		{
			System.out.println("Invalid object");
			System.out.println(" ");
			userCommand();
		}

	}

}
